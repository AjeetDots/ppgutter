<?php
/**
 * Mailbox poller: reads unread lead-notification emails over IMAP (WP-Cron, every 5 minutes),
 * identifies the platform from the sender, parses the lead and sends it to HubSpot.
 *
 * Config (wp-config.php constants or env vars):
 *   PPG_IMAP_HOST  e.g. {imap.example.com:993/imap/ssl}INBOX
 *   PPG_IMAP_USER, PPG_IMAP_PASS
 */

defined( 'ABSPATH' ) || exit;

require_once __DIR__ . '/parsers.php';

/** Sender domain => platform slug. Subdomains match too (em.yell.com, services.checkatrade.com). */
function ppg_email_sources() {
	return array(
		'yelp.com'        => 'yelp',
		'yelp.co.uk'      => 'yelp',
		'yell.com'        => 'yell',
		'checkatrade.com' => 'checkatrade',
	);
}

add_filter( 'cron_schedules', function ( $s ) {
	$s['ppg_five_minutes'] = array( 'interval' => 300, 'display' => 'Every 5 minutes' );
	return $s;
} );

add_action( 'init', function () {
	if ( ! wp_next_scheduled( 'ppg_poll_mailbox' ) ) {
		wp_schedule_event( time() + 60, 'ppg_five_minutes', 'ppg_poll_mailbox' );
	}
} );

register_deactivation_hook( dirname( __FILE__ ) . '/ppg-lead-gateway.php', function () {
	wp_clear_scheduled_hook( 'ppg_poll_mailbox' );
} );

add_action( 'ppg_poll_mailbox', 'ppg_poll_mailbox' );

/** PPG_GO_LIVE, e.g. '2026-10-20 09:00:00 Europe/London'. Returns a Unix timestamp, or 0 if unset/invalid. */
function ppg_go_live_timestamp() {
	$value = (string) ppg_lead_cfg( 'PPG_GO_LIVE' );
	$ts    = '' === $value ? false : strtotime( $value );
	return $ts ? (int) $ts : 0;
}

/** Returns plain text for a message (prefers text/plain, falls back to stripped HTML). */
function ppg_email_text( $imap, $num ) {
	$structure = imap_fetchstructure( $imap, $num );
	$plain     = '';
	$html      = '';

	$walk = function ( $part, $path ) use ( &$walk, $imap, $num, &$plain, &$html ) {
		if ( ! empty( $part->parts ) ) {
			foreach ( $part->parts as $i => $sub ) {
				$walk( $sub, '' === $path ? (string) ( $i + 1 ) : $path . '.' . ( $i + 1 ) );
			}
			return;
		}
		if ( TYPETEXT !== $part->type ) {
			return;
		}
		$raw = imap_fetchbody( $imap, $num, '' === $path ? '1' : $path, FT_PEEK );
		if ( ENCBASE64 === $part->encoding ) {
			$raw = base64_decode( $raw );
		} elseif ( ENCQUOTEDPRINTABLE === $part->encoding ) {
			$raw = quoted_printable_decode( $raw );
		}
		foreach ( (array) ( $part->parameters ?? array() ) as $param ) {
			if ( 'charset' === strtolower( $param->attribute ) && 'utf-8' !== strtolower( $param->value ) && function_exists( 'mb_convert_encoding' ) ) {
				$raw = @mb_convert_encoding( $raw, 'UTF-8', $param->value );
			}
		}
		if ( 'PLAIN' === strtoupper( $part->subtype ) ) {
			$plain .= $raw;
		} elseif ( 'HTML' === strtoupper( $part->subtype ) ) {
			$html .= $raw;
		}
	};
	$walk( $structure, '' );

	// HTML-only emails (all the older Checkatrade ones) are converted to text for the parsers.
	return '' !== trim( $plain ) ? $plain : ppg_html_to_text( $html );
}

/** Atomic lock so two overlapping cron runs cannot import the same lead twice. */
function ppg_poll_lock_acquire() {
	$now = time();
	if ( add_option( 'ppg_poll_lock', $now, '', 'no' ) ) { // add_option fails if the row already exists
		return true;
	}
	if ( $now - (int) get_option( 'ppg_poll_lock' ) > 10 * MINUTE_IN_SECONDS ) { // stale lock from a crashed run
		update_option( 'ppg_poll_lock', $now, false );
		return true;
	}
	return false;
}

function ppg_poll_mailbox() {
	if ( ! ppg_poll_lock_acquire() ) {
		return; // another run is in progress
	}
	try {
		ppg_poll_mailbox_run();
	} finally {
		delete_option( 'ppg_poll_lock' );
	}
}

function ppg_poll_mailbox_run() {
	if ( ! function_exists( 'imap_open' ) ) {
		error_log( '[ppg-lead-gateway] PHP imap extension is not enabled; mailbox polling skipped.' );
		return;
	}
	$host = (string) ppg_lead_cfg( 'PPG_IMAP_HOST' );
	$user = (string) ppg_lead_cfg( 'PPG_IMAP_USER' );
	$pass = (string) ppg_lead_cfg( 'PPG_IMAP_PASS' );
	if ( '' === $host || '' === $user || '' === $pass ) {
		return;
	}

	$imap = @imap_open( $host, $user, $pass, 0, 1 );
	if ( ! $imap ) {
		error_log( '[ppg-lead-gateway] IMAP connect failed: ' . imap_last_error() );
		return;
	}

	// Search by sender and date, not by unread state, so a human opening the email first
	// does not hide it from us. Duplicates are prevented by the Message-ID dedupe key.
	// Only matching senders are ever fetched; other mail in the mailbox is never touched.
	// Import only emails received after the go-live time. Without PPG_GO_LIVE nothing is imported,
	// so the integration cannot pull in historical leads by accident.
	$go_live = ppg_go_live_timestamp();
	if ( ! $go_live ) {
		if ( ! get_transient( 'ppg_no_go_live_logged' ) ) {
			error_log( '[ppg-lead-gateway] PPG_GO_LIVE is not set (or invalid); mailbox import is disabled.' );
			set_transient( 'ppg_no_go_live_logged', 1, DAY_IN_SECONDS );
		}
		imap_close( $imap );
		return;
	}
	// IMAP SINCE is date-only (exact time is checked below). Only the last three days are searched, so a
	// long-running site does not re-read old mail; duplicate locks last two weeks.
	$since   = gmdate( 'd-M-Y', max( $go_live - DAY_IN_SECONDS, time() - 3 * DAY_IN_SECONDS ) );
	$matches = array();
	foreach ( array_keys( ppg_email_sources() ) as $domain ) {
		$found = imap_search( $imap, 'FROM "' . $domain . '" SINCE "' . $since . '"' );
		if ( $found ) {
			$matches = array_merge( $matches, $found );
		}
	}
	foreach ( array_unique( $matches ) as $num ) {
		$header = imap_headerinfo( $imap, $num );
		$from   = isset( $header->from[0] ) ? strtolower( $header->from[0]->host ?? '' ) : '';
		$source = '';
		foreach ( ppg_email_sources() as $domain => $slug ) {
			if ( $from === $domain || substr( $from, -strlen( '.' . $domain ) ) === '.' . $domain ) {
				$source = $slug;
				break;
			}
		}
		if ( '' === $source ) {
			continue; // Not a lead email; leave it unread for a human.
		}

		if ( empty( $header->udate ) || (int) $header->udate < $go_live ) {
			continue; // Received before go-live: never imported.
		}

		$subject = isset( $header->subject ) ? imap_utf8( $header->subject ) : '';

		// Cheap subject check first, so non-lead mail from these senders (login alerts, invoices,
		// verification codes, reminders, replies) is never even downloaded.
		if ( null === ppg_parse_lead_email( $source, $subject, '' ) ) {
			continue;
		}

		$body = ppg_email_text( $imap, $num );
		$lead = ppg_parse_lead_email( $source, $subject, $body );
		if ( null === $lead ) {
			continue;
		}

		// The Message-ID means the same email is never imported twice. A lead with no customer email is
		// still created (identified by its lead id); only an unprocessable lead goes to the review queue.
		$lead['dedupe_key'] = $header->message_id ?? md5( $subject . $body );
		$lead['subject']    = $subject;

		// The mailbox is never modified (no read flags). HubSpot failures are not remembered,
		// so the next run retries them.
		// ppg_lead_process() logs failures itself and queues the ones that cannot be retried.
		ppg_lead_process( $source, $lead );
	}
	imap_close( $imap );
}
